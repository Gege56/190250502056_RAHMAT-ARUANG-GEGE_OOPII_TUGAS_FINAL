package Kelas_TI;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
public class Uang_Kas {
void uangkasdua()throws IOException{
    Scanner input = new Scanner (System.in);
    BufferedReader dataIn = new BufferedReader (new InputStreamReader(System.in));
    Data Data = new Data();
    String nim, bayar, bulan;
    {
    System.out.println("-----INPUT UANG KAS-----"); 
     System.out.println("Masukkan NIM : ");
            nim = input.nextLine();
            System.out.println("Biodata Mahasiswa");
            System.out.println("NAMA : RAHMAT ARUANG GEGE");
            System.out.println("TTL : MAMASA, 26 NOVEMBER 2001");
            System.out.println("JURUSAN : TEKNIK INFORMATIKA");
            System.out.println("FAKULTAS : ILMU KOMPUTER");
            System.out.println("ANGKATAN : 2019");
            System.out.println("SEMESTER : 5 ");
            System.out.println("ALAMAT : JL ANDI DAI");
            System.out.println("NOHP : 085240796676");

        System.out.print("Pembayaran Bulan     : ");
        bulan = input.nextLine();
        System.out.print("Jumlah Pembayaran    : ");
        bayar = input.nextLine();
        System.out.println("-----------------------------------------------------------");
     
        System.out.println("Pembayaran Bulan     : "+bulan);
        System.out.println("Jumlah Pembayaran    : "+bayar);
        System.out.println("-----------------------------------------------------------");        
    }
        
    }
}
