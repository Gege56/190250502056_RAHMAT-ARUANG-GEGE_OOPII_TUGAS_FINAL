/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Kelas_TI;

/**
 *
 * @author NIKU
 */
public class Data {
private String nim,nama,ttl,jurusan,fakultas,angkatan,semester,alamat,nohp;
public void setNAMA (String nama)
{
    this.nama = nama;
}
public void setNIM (String nim)
{
    this.nim =nim;
}public void setTTL (String ttl)
{
    this.ttl = ttl;
}public void setJURUSAN (String jurusan)
{
    this.jurusan = jurusan;
}public void setFAKULTAS (String fakultas)
{
    this.fakultas = fakultas;
}public void setANGKATAN (String angkatan)
{
    this.angkatan = angkatan;
}public void setSEMESTER (String semester)
{
    this.semester = semester;
}
public void setALAMAT (String alamat)
{
    this.alamat = alamat;
}public void setNOHP (String nohp)
{
    this.nohp = nohp;
}
public String getNAMA()
{
    return nama;
}
public String getNIM()
{
    return nim;
}public String getTTL()
{
    return ttl;
}public String getJURUSAN()
{
    return jurusan;
}public String getFAKULTAS()
{
    return fakultas;
}public String getANGKATAN()
{
    return angkatan;
}public String getSEMESTER()
{
    return semester;
}public String getALAMAT()
{
    return alamat;
}public String getNOHP()
{
    return nohp;
}
}
