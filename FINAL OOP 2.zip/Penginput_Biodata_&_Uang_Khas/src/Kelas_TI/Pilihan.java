/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Kelas_TI;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Scanner;

public class Pilihan {

    public static void main(String[] args) throws IOException {
        BufferedReader dataIn = new BufferedReader(new InputStreamReader(System.in));
        Biodata pilih = new Biodata();
        Uang_Kas milih = new Uang_Kas();
        String kelas;
        Scanner input = new Scanner(System.in);

        for (int i = 0; i <= 10; i++) {
            System.out.println("-----------------------------------------------------------");
            System.out.println("|         Program Penginputan Biodata & Uang kas          |");
            System.out.println("-----------------------------------------------------------");
            System.out.println("| 1. Input Biodata                                        |");
            System.out.println("| 2. Input Uang kas                                       |");
            System.out.println("| 0. Keluar                                               |");
            System.out.println("-----------------------------------------------------------");
            System.out.print("Masukkan Pilihan : ");
            kelas = input.nextLine();

            System.out.println("-----------------------------------------------------------");
            switch (kelas) {
                case ("1"):
                    pilih.biodatasatu();
                    break;

                case ("2"):
                    milih.uangkasdua();
                    break;

                case ("0"): {
                    System.exit(0);
                    break;

                }
            }
        }
    }
}
