package Kelas_TI;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
public class Biodata {

public void biodatasatu()throws IOException{
    Scanner input = new Scanner (System.in);
    Data Kelas_TI = new Data();
   BufferedReader dataIn = new BufferedReader (new InputStreamReader(System.in));
        String Nama, Nim, Jurusan, Fakultas, Angkatan, Semester, ttl, Alamat, Nohp;
            System.out.println("-----INPUT BIODATA MAHASISWA-----");
            
            System.out.print("Masukkan NIM : ");
            String a = dataIn.readLine();
            Kelas_TI.setNIM(String.valueOf(a));
            Nim = input.nextLine();
            System.out.print("Masukkan NAMA : ");
            String b = dataIn.readLine();
            Kelas_TI.setNAMA(String.valueOf(b));
            Nama = input.nextLine(); 
            System.out.print("Masukkan TTL : ");
            String c = dataIn.readLine();
            Kelas_TI.setTTL(String.valueOf(c));
            ttl = input.nextLine();
            System.out.print("Masukkan JURUSAN : ");
            String d = dataIn.readLine();
            Kelas_TI.setJURUSAN(String.valueOf(d));
            Jurusan = input.nextLine();
            System.out.print("Masukkan FAKULTAS : ");
            String e = dataIn.readLine();
            Kelas_TI.setFAKULTAS(String.valueOf(e));
            Fakultas = input.nextLine();
            System.out.print("Masukkan ANGKATAN : ");
            String f = dataIn.readLine();
            Kelas_TI.setANGKATAN(String.valueOf(f));
            Angkatan = input.nextLine();
            System.out.print("Masukkan SEMESTER : ");
            String g = dataIn.readLine();
            Kelas_TI.setSEMESTER(String.valueOf(g));
            Semester = input.nextLine();
            System.out.print("Masukkan ALAMAT : ");
            String h = dataIn.readLine();
            Kelas_TI.setALAMAT(String.valueOf(h));
            Alamat = input.nextLine();
            System.out.print("Masukkan NO Hape : ");
            String i = dataIn.readLine();
            Kelas_TI.setNOHP(String.valueOf(i));
            Nohp = input.nextLine();
            System.out.println("NAMA : "+Kelas_TI.getNAMA());
            System.out.println("NIM : "+Kelas_TI.getNIM());
            System.out.println("TTL : "+Kelas_TI.getTTL());
            System.out.println("JURUSAN : "+Kelas_TI.getJURUSAN());
            System.out.println("FAKULTAS : "+Kelas_TI.getFAKULTAS());
            System.out.println("ANGKATAN : "+Kelas_TI.getANGKATAN());
            System.out.println("SEMESTER : "+Kelas_TI.getSEMESTER());
            System.out.println("ALAMAT : "+Kelas_TI.getALAMAT());
            System.out.println("NOHP : "+Kelas_TI.getNOHP());

}
             
            
           
           
        
    }




